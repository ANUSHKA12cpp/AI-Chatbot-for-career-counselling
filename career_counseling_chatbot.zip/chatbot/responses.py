
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def get_bot_response(message):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an expert career counselor."},
                {"role": "user", "content": message}
            ],
            max_tokens=200,
            temperature=0.6
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        return "Sorry, I'm having trouble responding right now. Please try again later."
