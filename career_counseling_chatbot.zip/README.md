
# AI Career Counseling Chatbot

A web-based chatbot using OpenAI and NLTK to guide users with career decisions.

## Features
- Natural language chat
- AI-powered responses
- Clean and responsive UI

## Setup
```bash
pip install -r requirements.txt
python app.py
```
