
async function sendMessage() {
    const userInput = document.getElementById("user-input");
    const message = userInput.value;
    if (!message) return;

    appendMessage("You", message);
    userInput.value = "";

    const res = await fetch("/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message })
    });

    const data = await res.json();
    appendMessage("Bot", data.response);
}

function appendMessage(sender, text) {
    const chatBox = document.getElementById("chat-box");
    const messageElem = document.createElement("div");
    messageElem.innerHTML = `<strong>${sender}:</strong> ${text}`;
    chatBox.appendChild(messageElem);
    chatBox.scrollTop = chatBox.scrollHeight;
}
